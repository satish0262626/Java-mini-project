package Project;
import java.sql.*;

import org.apache.tomcat.dbcp.dbcp2.DriverManagerConnectionFactory;
public class ConnectionProvider {
	public static Connection getCon() {
		{
			
			try {
			     Class.forName("com.mysql.jdbc.Driver")	;
			 Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3307/student","root","root");
			 
			 
			 return con;
			     
			} catch (Exception e) {
				// TODO: handle exception
			System.out.println(e); 
			return null;
			}
		}
	}
	
	
}
